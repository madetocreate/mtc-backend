# Modell-Konfiguration geladen.
