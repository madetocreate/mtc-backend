📘 Das ist ein umfangreicher Testtext für das Memory-Upload-System. Er enthält wichtige Infos über AION, GPT und Tokenfilterung.
Wir testen gleich, ob alles korrekt ins Memory geladen, zusammengefasst und gefiltert wird.
