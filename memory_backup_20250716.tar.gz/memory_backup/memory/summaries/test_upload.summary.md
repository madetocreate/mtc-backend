**Titel:** Testtext für das Memory-Upload-System 

**Themen:**
- AION
- GPT
- Tokenfilterung
- Memory-Upload-System

**Tags:**
- Test
- Memory
- Infos
- Filterung