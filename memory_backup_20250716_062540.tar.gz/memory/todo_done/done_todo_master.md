Schreibe eine Landingpage über AION.
Erstelle einen Atomic Bot für Audio-Kommentare.
Sortiere alle Markdown-Dateien im Memory nach Thema.
