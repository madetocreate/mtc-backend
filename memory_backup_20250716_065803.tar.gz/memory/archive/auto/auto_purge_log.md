# Auto-Purge Log für Memory-Einträge
