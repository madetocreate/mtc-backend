#!/usr/bin/env python3
import os, shutil
print("Memory-Monitor aktiv")
